from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any, Optional, Union
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm
import io
import base64
import warnings

warnings.filterwarnings('ignore')

router = APIRouter()


class AcfPacfRequest(BaseModel):
    data: Union[List[float], List[Dict[str, Any]]]
    valueCol: Optional[str] = None
    lags: int = 40


def _to_native(obj):
    if isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, np.floating):
        if np.isnan(obj) or np.isinf(obj):
            return None
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return [_to_native(x) for x in obj.tolist()]
    elif isinstance(obj, dict):
        return {k: _to_native(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_to_native(x) for x in obj]
    return obj


def safe_float(val, default=0.0):
    try:
        if val is None or (isinstance(val, float) and (np.isnan(val) or np.isinf(val))):
            return default
        return float(val)
    except:
        return default


@router.post("/acf-pacf")
async def acf_pacf_analysis(request: AcfPacfRequest):
    try:
        data = request.data
        value_col = request.valueCol
        lags = request.lags

        # Handle both formats: array of numbers OR array of objects
        if len(data) > 0 and isinstance(data[0], (int, float)):
            series = pd.Series(data).dropna()
        else:
            df = pd.DataFrame(data)
            if value_col and value_col in df.columns:
                series = pd.to_numeric(df[value_col], errors='coerce').dropna()
            else:
                # Try first numeric column
                numeric_cols = df.select_dtypes(include=[np.number]).columns
                if len(numeric_cols) == 0:
                    raise HTTPException(status_code=400, detail="No numeric columns found")
                series = df[numeric_cols[0]].dropna()

        if len(series) < lags * 2:
            raise HTTPException(
                status_code=400,
                detail=f"Not enough data. Need at least {lags * 2} points, have {len(series)}."
            )

        # Limit lags to valid range
        max_lags = min(lags, len(series) // 2 - 1)
        if max_lags < 1:
            max_lags = 1

        # ACF and PACF Calculation
        acf_values = sm.tsa.acf(series, nlags=max_lags, fft=True)
        pacf_values = sm.tsa.pacf(series, nlags=max_lags, method='ywm')

        # Confidence interval (95%)
        conf_int = 1.96 / np.sqrt(len(series))

        # Find significant lags
        significant_acf = [i for i, v in enumerate(acf_values) if i > 0 and abs(v) > conf_int]
        significant_pacf = [i for i, v in enumerate(pacf_values) if i > 0 and abs(v) > conf_int]

        # Determine AR and MA order suggestions
        # AR order: where PACF cuts off
        ar_order = 0
        for i in range(1, len(pacf_values)):
            if abs(pacf_values[i]) > conf_int:
                ar_order = i
            else:
                break

        # MA order: where ACF cuts off
        ma_order = 0
        for i in range(1, len(acf_values)):
            if abs(acf_values[i]) > conf_int:
                ma_order = i
            else:
                break

        # Model recommendation
        if ar_order == 0 and ma_order == 0:
            model_rec = "White noise - no ARIMA modeling needed"
        elif ar_order > 0 and ma_order == 0:
            model_rec = f"Pure AR({ar_order}) process suggested"
        elif ar_order == 0 and ma_order > 0:
            model_rec = f"Pure MA({ma_order}) process suggested"
        else:
            model_rec = f"ARIMA({ar_order},d,{ma_order}) suggested - determine d via stationarity tests"

        # Plotting
        fig, axes = plt.subplots(2, 1, figsize=(12, 8))
        fig.suptitle('ACF & PACF Analysis', fontsize=14, fontweight='bold')

        # ACF Plot
        sm.graphics.tsa.plot_acf(series, lags=max_lags, ax=axes[0], fft=True)
        axes[0].set_title(f'Autocorrelation Function (ACF) - MA order suggestion: q={ma_order}', fontsize=11)
        axes[0].axhline(y=conf_int, color='red', linestyle='--', alpha=0.5, label='95% CI')
        axes[0].axhline(y=-conf_int, color='red', linestyle='--', alpha=0.5)
        axes[0].grid(True, linestyle='--', alpha=0.6)

        # PACF Plot
        sm.graphics.tsa.plot_pacf(series, lags=max_lags, ax=axes[1], method='ywm')
        axes[1].set_title(f'Partial Autocorrelation Function (PACF) - AR order suggestion: p={ar_order}', fontsize=11)
        axes[1].axhline(y=conf_int, color='red', linestyle='--', alpha=0.5, label='95% CI')
        axes[1].axhline(y=-conf_int, color='red', linestyle='--', alpha=0.5)
        axes[1].grid(True, linestyle='--', alpha=0.6)

        plt.tight_layout()

        buf = io.BytesIO()
        plt.savefig(buf, format='png', dpi=120, bbox_inches='tight', facecolor='white')
        plt.close(fig)
        buf.seek(0)
        plot_b64 = base64.b64encode(buf.read()).decode('utf-8')

        # Results
        results = {
            'acf': [safe_float(v) for v in acf_values.tolist()],
            'pacf': [safe_float(v) for v in pacf_values.tolist()],
            'lags': max_lags,
            'confidence_interval': safe_float(conf_int),
            'significant_acf_lags': significant_acf,
            'significant_pacf_lags': significant_pacf,
            'ar_order_suggestion': ar_order,
            'ma_order_suggestion': ma_order,
            'model_recommendation': model_rec,
            'n_observations': len(series)
        }

        return _to_native({
            'results': results,
            'plot': f"data:image/png;base64,{plot_b64}"
        })

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
