from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy import stats
import warnings
import traceback

warnings.filterwarnings('ignore')

router = APIRouter()


# ══════════════════════════════════════════════════════════════
# Request Model
# ══════════════════════════════════════════════════════════════

class FamaFrenchRequest(BaseModel):
    data: Optional[List[Dict[str, Any]]] = None
    returnCol: Optional[str] = None          # stock/portfolio return column
    dateCol: Optional[str] = None            # date column
    mktRfCol: Optional[str] = None           # Market - Rf column
    smbCol: Optional[str] = None             # SMB column
    hmlCol: Optional[str] = None             # HML column
    rfCol: Optional[str] = None              # Risk-free rate column
    # Generate mode
    generate: bool = False
    ticker: str = "AAPL"
    nMonths: int = 120                        # 10 years default
    seed: Optional[int] = None
    # Rolling analysis
    rollingWindow: int = 36                   # 36-month rolling
    # Scenario analysis
    scenarioProfiles: Optional[List[Dict[str, float]]] = None


# ══════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════

def _to_native(obj):
    """Recursively convert numpy types to Python native for JSON."""
    if isinstance(obj, (np.integer,)):
        return int(obj)
    elif isinstance(obj, (np.floating,)):
        if np.isnan(obj) or np.isinf(obj):
            return None
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return [_to_native(x) for x in obj.tolist()]
    elif isinstance(obj, np.bool_):
        return bool(obj)
    elif isinstance(obj, dict):
        return {k: _to_native(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_to_native(x) for x in obj]
    return obj


def safe_float(val, default=0.0):
    try:
        if val is None:
            return default
        f = float(val)
        if np.isnan(f) or np.isinf(f):
            return default
        return f
    except Exception:
        return default


# ══════════════════════════════════════════════════════════════
# Data Generator — Realistic Fama-French Factors + Stock Returns
# ══════════════════════════════════════════════════════════════

# Stock profiles — realistic beta/loading characteristics
STOCK_PROFILES = {
    'AAPL':  {'name': 'Apple Inc.',           'beta': 1.20, 'smb': -0.15, 'hml': -0.45, 'alpha': 0.005, 'sigma': 0.04},
    'MSFT':  {'name': 'Microsoft Corp.',      'beta': 1.10, 'smb': -0.20, 'hml': -0.30, 'alpha': 0.004, 'sigma': 0.035},
    'GOOGL': {'name': 'Alphabet Inc.',        'beta': 1.05, 'smb': -0.18, 'hml': -0.40, 'alpha': 0.003, 'sigma': 0.04},
    'AMZN':  {'name': 'Amazon.com Inc.',      'beta': 1.25, 'smb': -0.10, 'hml': -0.55, 'alpha': 0.004, 'sigma': 0.05},
    'TSLA':  {'name': 'Tesla Inc.',           'beta': 1.80, 'smb':  0.30, 'hml': -0.70, 'alpha': 0.006, 'sigma': 0.10},
    'JPM':   {'name': 'JPMorgan Chase',       'beta': 1.15, 'smb': -0.05, 'hml':  0.60, 'alpha': 0.002, 'sigma': 0.04},
    'JNJ':   {'name': 'Johnson & Johnson',    'beta': 0.65, 'smb': -0.25, 'hml':  0.30, 'alpha': 0.001, 'sigma': 0.025},
    'WMT':   {'name': 'Walmart Inc.',         'beta': 0.55, 'smb': -0.30, 'hml':  0.20, 'alpha': 0.001, 'sigma': 0.025},
    'XOM':   {'name': 'Exxon Mobil',          'beta': 0.90, 'smb': -0.10, 'hml':  0.70, 'alpha': 0.000, 'sigma': 0.04},
    'BRK.B': {'name': 'Berkshire Hathaway',   'beta': 0.85, 'smb': -0.15, 'hml':  0.40, 'alpha': 0.003, 'sigma': 0.03},
    'NVDA':  {'name': 'NVIDIA Corp.',         'beta': 1.60, 'smb':  0.10, 'hml': -0.60, 'alpha': 0.008, 'sigma': 0.08},
    'META':  {'name': 'Meta Platforms',       'beta': 1.30, 'smb': -0.12, 'hml': -0.35, 'alpha': 0.003, 'sigma': 0.05},
    'V':     {'name': 'Visa Inc.',            'beta': 0.95, 'smb': -0.20, 'hml': -0.15, 'alpha': 0.003, 'sigma': 0.03},
    'PG':    {'name': 'Procter & Gamble',     'beta': 0.50, 'smb': -0.30, 'hml':  0.25, 'alpha': 0.001, 'sigma': 0.02},
    'KO':    {'name': 'Coca-Cola Co.',        'beta': 0.55, 'smb': -0.28, 'hml':  0.15, 'alpha': 0.001, 'sigma': 0.02},
    'DIS':   {'name': 'Walt Disney Co.',      'beta': 1.10, 'smb': -0.05, 'hml':  0.10, 'alpha': 0.001, 'sigma': 0.04},
    'NFLX':  {'name': 'Netflix Inc.',         'beta': 1.35, 'smb':  0.05, 'hml': -0.50, 'alpha': 0.005, 'sigma': 0.07},
    'AMD':   {'name': 'AMD Inc.',             'beta': 1.70, 'smb':  0.25, 'hml': -0.55, 'alpha': 0.006, 'sigma': 0.09},
    'INTC':  {'name': 'Intel Corp.',          'beta': 1.05, 'smb':  0.00, 'hml':  0.20, 'alpha': -0.002, 'sigma': 0.05},
    'BA':    {'name': 'Boeing Co.',           'beta': 1.30, 'smb':  0.05, 'hml':  0.25, 'alpha': -0.001, 'sigma': 0.06},
}


def generate_ff3_data(
    ticker: str = 'AAPL',
    n_months: int = 120,
    seed: Optional[int] = None,
) -> pd.DataFrame:
    """
    Generate realistic monthly Fama-French 3 factor data + stock excess returns.

    Factor statistics calibrated to historical Kenneth French data library averages:
    - Mkt-RF: mean ~0.65%/month, std ~4.5%
    - SMB:    mean ~0.20%/month, std ~3.0%
    - HML:    mean ~0.30%/month, std ~3.0%
    - RF:     mean ~0.25%/month, std ~0.15%

    Factors have realistic cross-correlations.
    Stock returns follow: R_i - R_f = α + β₁(Mkt-RF) + β₂(SMB) + β₃(HML) + ε
    """
    rng = np.random.default_rng(seed)

    # Factor parameters (monthly, in decimal)
    factor_means = np.array([0.0065, 0.0020, 0.0030])   # Mkt-RF, SMB, HML
    factor_stds = np.array([0.045, 0.030, 0.030])

    # Correlation matrix (realistic)
    corr = np.array([
        [1.00, 0.30, -0.25],
        [0.30, 1.00,  0.10],
        [-0.25, 0.10, 1.00],
    ])
    cov = np.outer(factor_stds, factor_stds) * corr

    # Generate correlated factors
    factors = rng.multivariate_normal(factor_means, cov, size=n_months)
    mkt_rf = factors[:, 0]
    smb = factors[:, 1]
    hml = factors[:, 2]

    # Risk-free rate (slowly varying, mean ~0.25%/month ≈ 3% annual)
    rf_base = 0.0025
    rf_noise = rng.normal(0, 0.0005, n_months)
    rf = np.maximum(rf_base + np.cumsum(rf_noise * 0.1), 0.0001)
    rf = rf - rf.mean() + rf_base  # re-center

    # Stock loadings
    profile = STOCK_PROFILES.get(ticker.upper(), {
        'name': ticker, 'beta': 1.0, 'smb': 0.0, 'hml': 0.0,
        'alpha': 0.002, 'sigma': 0.04,
    })

    alpha = profile['alpha']
    beta_mkt = profile['beta']
    beta_smb = profile['smb']
    beta_hml = profile['hml']
    sigma_eps = profile['sigma']

    # Generate excess returns
    epsilon = rng.normal(0, sigma_eps, n_months)
    excess_return = alpha + beta_mkt * mkt_rf + beta_smb * smb + beta_hml * hml + epsilon
    stock_return = excess_return + rf

    # Dates (monthly, going back from recent)
    end_date = pd.Timestamp('2025-04-30')
    dates = pd.date_range(end=end_date, periods=n_months, freq='ME')

    df = pd.DataFrame({
        'date': dates.strftime('%Y-%m'),
        'stock_return': np.round(stock_return * 100, 4),       # in %
        'excess_return': np.round(excess_return * 100, 4),     # in %
        'Mkt_RF': np.round(mkt_rf * 100, 4),                  # in %
        'SMB': np.round(smb * 100, 4),
        'HML': np.round(hml * 100, 4),
        'RF': np.round(rf * 100, 4),
    })

    return df, profile


# ══════════════════════════════════════════════════════════════
# OLS Regression — Fama-French 3 Factor
# ══════════════════════════════════════════════════════════════

def run_ff3_regression(
    df: pd.DataFrame,
    y_col: str,
    factor_cols: List[str],
):
    """
    Run Fama-French 3-factor OLS regression using statsmodels.

    Model: R_i - R_f = α + β₁(Mkt-RF) + β₂(SMB) + β₃(HML) + ε

    Returns:
        results dict with coefficients, t-stats, p-values, R², etc.
    """
    y = df[y_col].values.astype(np.float64)
    X = df[factor_cols].values.astype(np.float64)
    X = sm.add_constant(X)

    model = sm.OLS(y, X)
    results = model.fit()

    # Factor names including alpha
    param_names = ['alpha'] + factor_cols

    # Coefficient details
    coefficients = []
    for i, name in enumerate(param_names):
        coefficients.append({
            'factor': name,
            'coefficient': safe_float(results.params[i]),
            'std_error': safe_float(results.bse[i]),
            't_stat': safe_float(results.tvalues[i]),
            'p_value': safe_float(results.pvalues[i]),
            'ci_lower': safe_float(results.conf_int()[i, 0]),
            'ci_upper': safe_float(results.conf_int()[i, 1]),
            'significant': bool(results.pvalues[i] < 0.05),
        })

    # Residual analysis
    residuals = results.resid
    fitted = results.fittedvalues

    # Durbin-Watson
    dw = safe_float(sm.stats.durbin_watson(residuals))

    # Jarque-Bera test for normality
    jb_stat, jb_pval, jb_skew, jb_kurtosis = sm.stats.jarque_bera(residuals)

    # Breusch-Pagan test for heteroskedasticity
    try:
        bp_stat, bp_pval, _, _ = sm.stats.diagnostic.het_breuschpagan(residuals, X)
    except Exception:
        bp_stat, bp_pval = 0.0, 1.0

    # VIF (Variance Inflation Factor)
    from statsmodels.stats.outliers_influence import variance_inflation_factor
    vif_values = []
    for j in range(1, X.shape[1]):  # skip constant
        try:
            vif_val = variance_inflation_factor(X, j)
            vif_values.append({
                'factor': factor_cols[j - 1],
                'vif': safe_float(vif_val),
            })
        except Exception:
            vif_values.append({
                'factor': factor_cols[j - 1],
                'vif': None,
            })

    return {
        'coefficients': coefficients,
        'r_squared': safe_float(results.rsquared),
        'adj_r_squared': safe_float(results.rsquared_adj),
        'f_stat': safe_float(results.fvalue),
        'f_pvalue': safe_float(results.f_pvalue),
        'n_observations': int(results.nobs),
        'df_model': int(results.df_model),
        'df_resid': int(results.df_resid),
        'aic': safe_float(results.aic),
        'bic': safe_float(results.bic),
        'log_likelihood': safe_float(results.llf),
        'durbin_watson': dw,
        'jarque_bera': {
            'statistic': safe_float(jb_stat),
            'p_value': safe_float(jb_pval),
            'skewness': safe_float(jb_skew),
            'kurtosis': safe_float(jb_kurtosis),
        },
        'breusch_pagan': {
            'statistic': safe_float(bp_stat),
            'p_value': safe_float(bp_pval),
        },
        'vif': vif_values,
        'residuals': [safe_float(r) for r in residuals],
        'fitted_values': [safe_float(f) for f in fitted],
    }


# ══════════════════════════════════════════════════════════════
# Rolling Regression
# ══════════════════════════════════════════════════════════════

def rolling_regression(
    df: pd.DataFrame,
    y_col: str,
    factor_cols: List[str],
    window: int = 36,
):
    """
    Compute rolling-window OLS regressions (e.g., 36-month rolling beta).

    Returns time series of alpha, betas, R² for each window.
    """
    n = len(df)
    if n < window:
        return None

    results_list = []
    dates = df['date'].values if 'date' in df.columns else [str(i) for i in range(n)]

    for i in range(window, n + 1):
        sub = df.iloc[i - window:i]
        y = sub[y_col].values.astype(np.float64)
        X = sm.add_constant(sub[factor_cols].values.astype(np.float64))

        try:
            model = sm.OLS(y, X).fit()
            entry = {
                'date': str(dates[i - 1]),
                'alpha': safe_float(model.params[0]),
                'r_squared': safe_float(model.rsquared),
            }
            for j, col in enumerate(factor_cols):
                entry[f'beta_{col}'] = safe_float(model.params[j + 1])
                entry[f'tstat_{col}'] = safe_float(model.tvalues[j + 1])

            results_list.append(entry)
        except Exception:
            continue

    return results_list


# ══════════════════════════════════════════════════════════════
# Factor Decomposition — Return Attribution
# ══════════════════════════════════════════════════════════════

def factor_decomposition(
    df: pd.DataFrame,
    y_col: str,
    factor_cols: List[str],
    coefficients: List[Dict],
):
    """
    Decompose stock returns into factor contributions.

    Contribution of factor k = β_k × F_k(t)
    Alpha contribution = α (constant per period)
    Residual = actual - predicted
    """
    alpha = coefficients[0]['coefficient']
    betas = {c['factor']: c['coefficient'] for c in coefficients[1:]}

    decomp = []
    dates = df['date'].values if 'date' in df.columns else [str(i) for i in range(len(df))]

    cumulative = {'alpha': 0, 'residual': 0}
    for fc in factor_cols:
        cumulative[fc] = 0

    for i in range(len(df)):
        row = df.iloc[i]
        actual = float(row[y_col])
        predicted = alpha
        entry = {
            'date': str(dates[i]),
            'actual_return': safe_float(actual),
            'alpha_contrib': safe_float(alpha),
        }

        for fc in factor_cols:
            contrib = betas.get(fc, 0) * float(row[fc])
            entry[f'{fc}_contrib'] = safe_float(contrib)
            predicted += contrib
            cumulative[fc] += contrib

        residual = actual - predicted
        entry['residual'] = safe_float(residual)
        entry['predicted'] = safe_float(predicted)

        cumulative['alpha'] += alpha
        cumulative['residual'] += residual

        # Cumulative contributions
        entry['cum_actual'] = safe_float(sum(float(df.iloc[j][y_col]) for j in range(i + 1)))
        entry['cum_alpha'] = safe_float(cumulative['alpha'])
        for fc in factor_cols:
            entry[f'cum_{fc}'] = safe_float(cumulative[fc])
        entry['cum_residual'] = safe_float(cumulative['residual'])

        decomp.append(entry)

    # Summary: average contributions
    n = len(df)
    total_return = sum(float(df.iloc[i][y_col]) for i in range(n))
    summary = {
        'total_return': safe_float(total_return),
        'alpha_total': safe_float(cumulative['alpha']),
        'alpha_pct': safe_float(cumulative['alpha'] / total_return * 100) if total_return != 0 else 0,
        'residual_total': safe_float(cumulative['residual']),
    }
    for fc in factor_cols:
        summary[f'{fc}_total'] = safe_float(cumulative[fc])
        summary[f'{fc}_pct'] = safe_float(cumulative[fc] / total_return * 100) if total_return != 0 else 0

    return decomp, summary


# ══════════════════════════════════════════════════════════════
# Scenario Analysis
# ══════════════════════════════════════════════════════════════

def scenario_analysis(
    coefficients: List[Dict],
    factor_cols: List[str],
    scenarios: List[Dict[str, float]],
):
    """
    Given hypothetical factor returns, predict stock excess return.

    Each scenario: { 'label': '...', 'Mkt_RF': x, 'SMB': y, 'HML': z }
    Predicted R_excess = α + β₁×Mkt-RF + β₂×SMB + β₃×HML
    """
    alpha = coefficients[0]['coefficient']
    betas = {c['factor']: c['coefficient'] for c in coefficients[1:]}

    results = []
    for scenario in scenarios:
        predicted = alpha
        contributions = {'alpha': safe_float(alpha)}
        for fc in factor_cols:
            val = scenario.get(fc, 0.0)
            contrib = betas.get(fc, 0) * val
            predicted += contrib
            contributions[fc] = safe_float(contrib)

        results.append({
            'label': scenario.get('label', 'Scenario'),
            'predicted_return': safe_float(predicted),
            'contributions': contributions,
            'factor_values': {fc: safe_float(scenario.get(fc, 0)) for fc in factor_cols},
        })

    return results


# ══════════════════════════════════════════════════════════════
# Main Endpoint
# ══════════════════════════════════════════════════════════════

@router.post("/fama-french")
async def fama_french_analysis(request: FamaFrenchRequest):
    try:
        factor_cols = ['Mkt_RF', 'SMB', 'HML']
        profile = None

        # ── 1. Get Data ──
        if request.generate or not request.data:
            # Generate synthetic data
            df, profile = generate_ff3_data(
                ticker=request.ticker,
                n_months=request.nMonths,
                seed=request.seed,
            )
            y_col = 'excess_return'
            date_col = 'date'
        else:
            # Use uploaded data
            df = pd.DataFrame(request.data)
            y_col = request.returnCol or 'excess_return'
            date_col = request.dateCol or 'date'
            fc_map = {
                'Mkt_RF': request.mktRfCol or 'Mkt_RF',
                'SMB': request.smbCol or 'SMB',
                'HML': request.hmlCol or 'HML',
            }
            # Rename columns if needed
            rename_map = {}
            for std_name, user_name in fc_map.items():
                if user_name != std_name and user_name in df.columns:
                    rename_map[user_name] = std_name
            if rename_map:
                df = df.rename(columns=rename_map)

            # Validate
            for col in [y_col] + factor_cols:
                if col not in df.columns:
                    raise HTTPException(status_code=400, detail=f"Column '{col}' not found. Available: {list(df.columns)}")

            df[y_col] = pd.to_numeric(df[y_col], errors='coerce')
            for fc in factor_cols:
                df[fc] = pd.to_numeric(df[fc], errors='coerce')
            df = df.dropna(subset=[y_col] + factor_cols)

        n = len(df)
        if n < 10:
            raise HTTPException(status_code=400, detail=f"Need at least 10 observations, got {n}")

        # ── 2. Run OLS Regression ──
        reg_results = run_ff3_regression(df, y_col, factor_cols)

        # ── 3. Rolling Regression ──
        rolling = rolling_regression(df, y_col, factor_cols, window=request.rollingWindow)

        # ── 4. Factor Decomposition ──
        decomp, decomp_summary = factor_decomposition(
            df, y_col, factor_cols, reg_results['coefficients']
        )

        # ── 5. Scenario Analysis ──
        scenario_results = None
        if request.scenarioProfiles and len(request.scenarioProfiles) >= 1:
            scenario_results = scenario_analysis(
                reg_results['coefficients'], factor_cols, request.scenarioProfiles
            )

        # ── 6. Chart Data ──

        # Time series chart
        time_series_data = []
        dates = df['date'].values if 'date' in df.columns else [str(i) for i in range(n)]
        for i in range(n):
            row = df.iloc[i]
            time_series_data.append({
                'date': str(dates[i]),
                'excess_return': safe_float(row[y_col]),
                'Mkt_RF': safe_float(row['Mkt_RF']),
                'SMB': safe_float(row['SMB']),
                'HML': safe_float(row['HML']),
            })

        # Coefficient chart data
        coef_chart_data = []
        for c in reg_results['coefficients']:
            coef_chart_data.append({
                'factor': c['factor'],
                'coefficient': c['coefficient'],
                'ci_lower': c['ci_lower'],
                'ci_upper': c['ci_upper'],
                'significant': c['significant'],
                'label': 'α (Alpha)' if c['factor'] == 'alpha' else
                         'β₁ (Market)' if c['factor'] == 'Mkt_RF' else
                         'β₂ (SMB)' if c['factor'] == 'SMB' else
                         'β₃ (HML)' if c['factor'] == 'HML' else c['factor'],
            })

        # Residual chart data
        residual_chart = []
        for i in range(n):
            residual_chart.append({
                'date': str(dates[i]),
                'residual': reg_results['residuals'][i],
                'fitted': reg_results['fitted_values'][i],
                'actual': safe_float(df.iloc[i][y_col]),
            })

        # Factor correlation matrix
        factor_data = df[factor_cols + [y_col]]
        corr_matrix = factor_data.corr()
        corr_data = {}
        for col in corr_matrix.columns:
            corr_data[col] = {c: safe_float(corr_matrix.loc[col, c]) for c in corr_matrix.columns}

        # Decomposition attribution chart (pie data)
        attrib_chart = []
        if decomp_summary:
            for fc in factor_cols:
                attrib_chart.append({
                    'factor': fc,
                    'contribution': safe_float(decomp_summary.get(f'{fc}_total', 0)),
                    'pct': safe_float(decomp_summary.get(f'{fc}_pct', 0)),
                })
            attrib_chart.append({
                'factor': 'Alpha',
                'contribution': safe_float(decomp_summary.get('alpha_total', 0)),
                'pct': safe_float(decomp_summary.get('alpha_pct', 0)),
            })
            attrib_chart.append({
                'factor': 'Residual',
                'contribution': safe_float(decomp_summary.get('residual_total', 0)),
                'pct': safe_float(abs(decomp_summary.get('residual_total', 0)) / abs(decomp_summary.get('total_return', 1)) * 100),
            })

        # ── 7. Factor descriptive statistics ──
        factor_stats = {}
        for col in factor_cols + [y_col]:
            series = df[col].astype(float)
            factor_stats[col] = {
                'mean': safe_float(series.mean()),
                'std': safe_float(series.std()),
                'min': safe_float(series.min()),
                'max': safe_float(series.max()),
                'skewness': safe_float(series.skew()),
                'kurtosis': safe_float(series.kurtosis()),
                'sharpe': safe_float(series.mean() / series.std() * np.sqrt(12)) if series.std() > 0 else 0,
            }

        # ── 8. Build Response ──
        results = {
            'ticker': request.ticker,
            'stock_profile': profile if profile else None,
            'regression': {
                'coefficients': reg_results['coefficients'],
                'r_squared': reg_results['r_squared'],
                'adj_r_squared': reg_results['adj_r_squared'],
                'f_stat': reg_results['f_stat'],
                'f_pvalue': reg_results['f_pvalue'],
                'n_observations': reg_results['n_observations'],
                'aic': reg_results['aic'],
                'bic': reg_results['bic'],
                'log_likelihood': reg_results['log_likelihood'],
            },
            'diagnostics': {
                'durbin_watson': reg_results['durbin_watson'],
                'jarque_bera': reg_results['jarque_bera'],
                'breusch_pagan': reg_results['breusch_pagan'],
                'vif': reg_results['vif'],
            },
            'factor_stats': factor_stats,
            'correlation': corr_data,
            'rolling': rolling,
            'decomposition': decomp,
            'decomposition_summary': decomp_summary,
            'scenarios': scenario_results,
            'data_summary': {
                'n_observations': n,
                'date_range': f"{dates[0]} to {dates[-1]}" if len(dates) > 0 else '',
                'rolling_window': request.rollingWindow,
            },
            'charts': {
                'time_series': time_series_data,
                'coefficient_chart': coef_chart_data,
                'residual_chart': residual_chart,
                'attribution_chart': attrib_chart,
            },
            'available_tickers': list(STOCK_PROFILES.keys()),
        }

        return _to_native({'results': results})

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"{str(e)}\n{traceback.format_exc()}")
