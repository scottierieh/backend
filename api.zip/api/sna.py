from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any, Optional, Literal
import pandas as pd
import numpy as np
import networkx as nx
import json
import logging

logger = logging.getLogger(__name__)

router = APIRouter()

# Duplicate-edge aggregation policies for weighted networks.
# - "sum"  : accumulated weight (e.g. total transaction volume)
# - "mean" : average weight    (e.g. average interaction strength)
# - "first": keep first occurrence (insertion order)
# - "last" : keep last occurrence
DuplicatePolicy = Literal["sum", "mean", "first", "last"]

# Fix 4: Weight interpretation policy for path-based metrics.
# - "strength" : higher weight = stronger connection → distance = 1/weight
# - "distance" : weight IS a cost/distance → used directly, no inversion
WeightInterpretation = Literal["strength", "distance"]

# Fix 2: How to handle negative edge weights in path-based (distance) metrics.
# - "error"    : raise HTTPException – prevents silent misinterpretation
# - "ignore"   : exclude negative edges from distance graph only;
#                they still count toward degree/strength metrics
# - "absolute" : use |w| as weight (signed networks where sign = polarity)
NegativeWeightPolicy = Literal["error", "ignore", "absolute"]


class SnaRequest(BaseModel):
    data: List[Dict[str, Any]]
    sourceCol: str
    targetCol: str
    weightCol: Optional[str] = None
    isDirected: bool = False
    duplicatePolicy: DuplicatePolicy = "sum"
    weightInterpretation: WeightInterpretation = "strength"
    negativeWeightPolicy: NegativeWeightPolicy = "ignore"


def _to_native(obj):
    if isinstance(obj, np.integer):
        return int(obj)
    elif isinstance(obj, np.floating):
        if np.isnan(obj) or np.isinf(obj):
            return None
        return float(obj)
    elif isinstance(obj, np.ndarray):
        return [_to_native(x) for x in obj.tolist()]
    elif isinstance(obj, np.bool_):
        return bool(obj)
    elif isinstance(obj, dict):
        return {k: _to_native(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_to_native(x) for x in obj]
    return obj


def _validate_network_data(
    df: pd.DataFrame,
    source_col: str,
    target_col: str,
    weight_col: Optional[str],
    duplicate_policy: DuplicatePolicy,
    negative_weight_policy: NegativeWeightPolicy,
) -> dict:
    """
    Validate network edge data and return a summary of detected issues.
    Raises HTTPException on critical errors; returns warnings dict for non-fatal issues.
    """
    # ── Critical checks ──────────────────────────────────────────────────────
    if source_col not in df.columns:
        raise HTTPException(status_code=400, detail=f"Source column '{source_col}' not found")
    if target_col not in df.columns:
        raise HTTPException(status_code=400, detail=f"Target column '{target_col}' not found")
    if weight_col and weight_col not in df.columns:
        raise HTTPException(status_code=400, detail=f"Weight column '{weight_col}' not found")

    warnings: dict = {}

    # ── Self-loops ────────────────────────────────────────────────────────────
    self_loop_mask = df[source_col].astype(str) == df[target_col].astype(str)
    n_self_loops = int(self_loop_mask.sum())
    if n_self_loops:
        warnings["self_loops"] = f"{n_self_loops} self-loop(s) detected and removed"
        logger.warning(warnings["self_loops"])

    # ── Duplicate edges ───────────────────────────────────────────────────────
    edge_pairs = df[[source_col, target_col]].astype(str)
    n_duplicates = int(edge_pairs.duplicated().sum())
    if n_duplicates:
        if weight_col:
            warnings["duplicate_edges"] = (
                f"{n_duplicates} duplicate edge(s) detected; "
                f"weights aggregated using policy='{duplicate_policy}'"
            )
        else:
            warnings["duplicate_edges"] = (
                f"{n_duplicates} duplicate edge(s) detected; "
                "collapsed into single unweighted edge (no weight column)"
            )
        logger.warning(warnings["duplicate_edges"])

    # ── Weight checks (Fix 2) ─────────────────────────────────────────────────
    if weight_col:
        w_series = pd.to_numeric(df[weight_col], errors="coerce")

        n_missing = int(w_series.isna().sum())
        if n_missing:
            warnings["weight_missing"] = (
                f"{n_missing} missing weight value(s) will default to 1.0"
            )
            logger.warning(warnings["weight_missing"])

        n_negative = int((w_series < 0).sum())
        if n_negative:
            if negative_weight_policy == "error":
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"{n_negative} negative weight(s) found. "
                        "Set negativeWeightPolicy='ignore' or 'absolute' to proceed."
                    ),
                )
            elif negative_weight_policy == "ignore":
                warnings["weight_negative"] = (
                    f"{n_negative} negative weight(s) detected. "
                    "They are excluded from distance-based path metrics "
                    "(betweenness, closeness) but included in degree/strength. "
                    "Set negativeWeightPolicy='absolute' to include them as |w|."
                )
            else:  # "absolute"
                warnings["weight_negative"] = (
                    f"{n_negative} negative weight(s) detected. "
                    "Absolute values |w| will be used for all metrics."
                )
            logger.warning(warnings["weight_negative"])

    # ── Isolated nodes detected after graph construction ──────────────────────
    return warnings


def _build_graph(
    df: pd.DataFrame,
    source_col: str,
    target_col: str,
    weight_col: Optional[str],
    is_directed: bool,
    duplicate_policy: DuplicatePolicy,
) -> nx.Graph:
    """
    Build a NetworkX graph from a DataFrame.

    Duplicate-edge handling (weighted networks only):
      - "sum"  : final edge weight = sum of all matching rows
      - "mean" : final edge weight = mean of all matching rows
      - "first": final edge weight = weight of first occurrence
      - "last" : final edge weight = weight of last occurrence

    For unweighted networks, duplicates collapse into a single edge
    (NetworkX Graph / DiGraph add_edges_from behaviour – no explicit
    deduplication needed because the graph stores at most one edge per pair).
    """
    G: nx.Graph = nx.DiGraph() if is_directed else nx.Graph()

    # Vectorised string conversion
    sources = df[source_col].astype(str)
    targets = df[target_col].astype(str)

    # Drop self-loops upfront
    mask = sources != targets
    sources = sources[mask]
    targets = targets[mask]

    if weight_col:
        weights = pd.to_numeric(df[weight_col], errors="coerce").fillna(1.0)[mask]

        # Build an edge DataFrame and apply the aggregation policy
        edge_df = pd.DataFrame({"source": sources, "target": targets, "weight": weights})

        if duplicate_policy == "sum":
            edge_df = edge_df.groupby(["source", "target"], sort=False)["weight"].sum().reset_index()
        elif duplicate_policy == "mean":
            edge_df = edge_df.groupby(["source", "target"], sort=False)["weight"].mean().reset_index()
        elif duplicate_policy == "first":
            edge_df = edge_df.groupby(["source", "target"], sort=False)["weight"].first().reset_index()
        else:  # "last"
            edge_df = edge_df.groupby(["source", "target"], sort=False)["weight"].last().reset_index()

        edges = [
            (row.source, row.target, {"weight": row.weight})
            for row in edge_df.itertuples(index=False)
        ]
    else:
        # Unweighted: just drop duplicate pairs (preserve first occurrence order)
        edge_df = pd.DataFrame({"source": sources, "target": targets}).drop_duplicates()
        edges = list(edge_df.itertuples(index=False, name=None))

    G.add_edges_from(edges)
    return G


def _build_distance_graph(
    G: nx.Graph,
    weight_interpretation: WeightInterpretation,
    negative_weight_policy: NegativeWeightPolicy,
) -> nx.Graph:
    """
    Return a copy of G with a 'distance' edge attribute suitable for
    shortest-path algorithms (NetworkX interprets weight as distance:
    lower = preferred).

    weight_interpretation="strength": distance = 1/|w| (stronger = shorter)
    weight_interpretation="distance": distance = w directly (already a cost)

    Negative-weight handling on the distance graph:
      "error"    – already rejected at validation; should not reach here
      "ignore"   – skip negative edges (set distance=inf so they are never used)
      "absolute" – use |w| before applying interpretation
    """
    G_dist = G.copy()
    for u, v, data in G_dist.edges(data=True):
        w = data.get("weight", 1.0)

        # Apply absolute-value policy before interpretation
        if negative_weight_policy == "absolute":
            w = abs(w)

        if w is None or (not negative_weight_policy == "absolute" and w <= 0):
            # ignore policy or zero weight: exclude from path metrics
            data["distance"] = float("inf")
        elif weight_interpretation == "strength":
            data["distance"] = 1.0 / w
        else:  # "distance"
            data["distance"] = w

    return G_dist


def _compute_centrality(
    G: nx.Graph,
    is_directed: bool,
    weighted: bool,
    weight_interpretation: WeightInterpretation = "strength",
    negative_weight_policy: NegativeWeightPolicy = "ignore",
) -> dict:
    """
    Compute a rich set of centrality measures, handling directed graphs properly.

    weighted=True  → strength-based degree / eigenvector / pagerank / katz /
                     clustering; path-based metrics use the distance graph built
                     according to weight_interpretation + negative_weight_policy.
    weighted=False → all metrics use pure graph topology.
    """
    centrality: dict = {}
    w_kwarg = {"weight": "weight"} if weighted else {}

    # ── Degree / strength centrality ──────────────────────────────────────────
    if weighted:
        n = G.number_of_nodes()
        norm = (n - 1) if n > 1 else 1
        centrality["degree"] = {
            node: strength / norm
            for node, strength in G.degree(weight="weight")
        }
    else:
        centrality["degree"] = nx.degree_centrality(G)

    if is_directed:
        if weighted:
            n = G.number_of_nodes()
            norm = (n - 1) if n > 1 else 1
            centrality["in_degree"] = {
                node: s / norm for node, s in G.in_degree(weight="weight")
            }
            centrality["out_degree"] = {
                node: s / norm for node, s in G.out_degree(weight="weight")
            }
        else:
            centrality["in_degree"] = nx.in_degree_centrality(G)
            centrality["out_degree"] = nx.out_degree_centrality(G)

    # ── Build distance graph for path-based metrics (Fix 2 + 4) ──────────────
    G_dist = (
        _build_distance_graph(G, weight_interpretation, negative_weight_policy)
        if weighted
        else G
    )
    dist_kwarg = {"weight": "distance"} if weighted else {}

    # ── Betweenness ───────────────────────────────────────────────────────────
    try:
        centrality["betweenness"] = nx.betweenness_centrality(G_dist, **dist_kwarg)
    except Exception as exc:
        logger.warning("Betweenness centrality failed: %s", exc)
        centrality["betweenness"] = {node: 0.0 for node in G.nodes()}

    # ── Closeness ─────────────────────────────────────────────────────────────
    try:
        centrality["closeness"] = nx.closeness_centrality(
            G_dist, distance="distance" if weighted else None
        )
    except Exception as exc:
        logger.warning("Closeness centrality failed: %s", exc)
        centrality["closeness"] = {node: 0.0 for node in G.nodes()}

    # ── Eigenvector centrality ────────────────────────────────────────────────
    try:
        centrality["eigenvector"] = nx.eigenvector_centrality(G, max_iter=1000, **w_kwarg)
    except nx.PowerIterationFailedConvergence:
        logger.warning("Eigenvector centrality did not converge; values set to 0.0")
        centrality["eigenvector"] = {node: 0.0 for node in G.nodes()}

    # ── PageRank ──────────────────────────────────────────────────────────────
    try:
        centrality["pagerank"] = nx.pagerank(G, max_iter=1000, **w_kwarg)
    except Exception as exc:
        logger.warning("PageRank failed: %s", exc)
        centrality["pagerank"] = {node: 0.0 for node in G.nodes()}

    # ── Katz centrality ───────────────────────────────────────────────────────
    try:
        centrality["katz"] = nx.katz_centrality(G, max_iter=1000, **w_kwarg)
    except Exception as exc:
        logger.warning("Katz centrality failed: %s", exc)
        centrality["katz"] = {node: 0.0 for node in G.nodes()}

    # ── Clustering coefficient (per node) ─────────────────────────────────────
    try:
        G_und = G.to_undirected() if is_directed else G
        centrality["clustering"] = nx.clustering(G_und, **w_kwarg)
    except Exception as exc:
        logger.warning("Clustering coefficient failed: %s", exc)
        centrality["clustering"] = {node: 0.0 for node in G.nodes()}

    return centrality


def _compute_network_metrics(
    G: nx.Graph,
    is_directed: bool,
    weighted: bool = False,
    weight_interpretation: WeightInterpretation = "strength",
    negative_weight_policy: NegativeWeightPolicy = "ignore",
) -> dict:
    """
    Compute comprehensive network-level metrics.

    When weighted=True, structural metrics (avg_degree, density) are
    supplemented with weighted counterparts (avg_strength, weighted_density,
    weighted_avg_path_length) that respect edge weights.
    """
    G_und = G.to_undirected() if is_directed else G

    metrics: dict = {
        "nodes": G.number_of_nodes(),
        "edges": G.number_of_edges(),
        # Structural (topology-only) density
        "density": nx.density(G),
        "is_connected": nx.is_connected(G_und),
        "components": nx.number_connected_components(G_und),
    }

    # ── Structural average degree ─────────────────────────────────────────────
    degrees = [d for _, d in G.degree()]
    metrics["avg_degree"] = float(np.mean(degrees)) if degrees else 0.0
    if is_directed:
        metrics["avg_in_degree"] = float(np.mean([d for _, d in G.in_degree()])) if degrees else 0.0
        metrics["avg_out_degree"] = float(np.mean([d for _, d in G.out_degree()])) if degrees else 0.0

    # ── Fix 1: Weighted network-level metrics ─────────────────────────────────
    if weighted:
        weights_all = [d.get("weight", 1.0) for _, _, d in G.edges(data=True)]
        weights_pos = [abs(w) if negative_weight_policy == "absolute" else w
                       for w in weights_all if w is not None and
                       (negative_weight_policy == "absolute" or w > 0)]

        # Node strength = sum of incident edge weights
        strengths = [s for _, s in G.degree(weight="weight")]
        metrics["avg_strength"] = float(np.mean(strengths)) if strengths else 0.0
        metrics["max_strength"] = float(np.max(strengths)) if strengths else 0.0
        metrics["min_strength"] = float(np.min(strengths)) if strengths else 0.0
        if is_directed:
            metrics["avg_in_strength"] = float(np.mean(
                [s for _, s in G.in_degree(weight="weight")]
            )) if strengths else 0.0
            metrics["avg_out_strength"] = float(np.mean(
                [s for _, s in G.out_degree(weight="weight")]
            )) if strengths else 0.0

        # Weighted density: sum(weights) / max_possible_weight_sum
        # Max possible = E_max * mean_weight where E_max = n*(n-1) for digraph else n*(n-1)/2
        n = G.number_of_nodes()
        if n > 1 and weights_pos:
            e_max = n * (n - 1) if is_directed else n * (n - 1) / 2
            metrics["weighted_density"] = float(sum(weights_pos) / (e_max * np.mean(weights_pos)))
        else:
            metrics["weighted_density"] = None

        # Weight distribution stats
        if weights_pos:
            metrics["weight_mean"] = float(np.mean(weights_pos))
            metrics["weight_std"] = float(np.std(weights_pos))
            metrics["weight_min"] = float(np.min(weights_pos))
            metrics["weight_max"] = float(np.max(weights_pos))
        else:
            metrics.update({"weight_mean": None, "weight_std": None,
                            "weight_min": None, "weight_max": None})

        # Weighted average path length (on distance graph, LCC only)
        try:
            G_dist = _build_distance_graph(G_und, weight_interpretation, negative_weight_policy)
            G_dist_lcc = (
                G_dist if nx.is_connected(G_dist)
                else G_dist.subgraph(max(nx.connected_components(G_dist), key=len))
            )
            metrics["weighted_avg_path_length"] = nx.average_shortest_path_length(
                G_dist_lcc, weight="distance"
            )
            if not nx.is_connected(G_dist):
                metrics["weighted_path_length_note"] = (
                    "Computed on the largest connected component"
                )
        except Exception as exc:
            logger.warning("Weighted path length failed: %s", exc)
            metrics["weighted_avg_path_length"] = None

        # Weighted clustering coefficient
        try:
            metrics["weighted_avg_clustering"] = nx.average_clustering(G_und, weight="weight")
        except Exception:
            metrics["weighted_avg_clustering"] = None

    # ── Structural clustering coefficient ─────────────────────────────────────
    try:
        metrics["avg_clustering"] = nx.average_clustering(G_und)
    except Exception:
        metrics["avg_clustering"] = None

    # ── Structural average path length & diameter (largest component) ─────────
    try:
        G_lcc = (
            G_und if nx.is_connected(G_und)
            else G_und.subgraph(max(nx.connected_components(G_und), key=len))
        )
        metrics["avg_path_length"] = nx.average_shortest_path_length(G_lcc)
        metrics["diameter"] = nx.diameter(G_lcc)
        if not nx.is_connected(G_und):
            metrics["path_length_note"] = "Computed on the largest connected component"
    except Exception as exc:
        logger.warning("Path length / diameter computation failed: %s", exc)
        metrics["avg_path_length"] = None
        metrics["diameter"] = None

    # ── Assortativity ─────────────────────────────────────────────────────────
    try:
        metrics["degree_assortativity"] = nx.degree_assortativity_coefficient(G)
    except Exception:
        metrics["degree_assortativity"] = None

    # ── Isolated nodes ────────────────────────────────────────────────────────
    isolated = list(nx.isolates(G))
    metrics["isolated_nodes"] = len(isolated)
    if isolated:
        logger.warning("%d isolated node(s) found: %s", len(isolated), isolated[:10])

    return metrics


@router.post("/sna")
async def social_network_analysis(request: SnaRequest):
    try:
        df = pd.DataFrame(request.data)
        source_col = request.sourceCol
        target_col = request.targetCol
        weight_col = request.weightCol
        is_directed = request.isDirected

        weighted = bool(weight_col)
        weight_interpretation = request.weightInterpretation
        negative_weight_policy = request.negativeWeightPolicy

        # ── 1. Validate data ──────────────────────────────────────────────────
        data_warnings = _validate_network_data(
            df, source_col, target_col, weight_col,
            request.duplicatePolicy, negative_weight_policy,
        )

        # ── 2. Build graph (vectorised, explicit duplicate aggregation) ───────
        G = _build_graph(
            df, source_col, target_col, weight_col, is_directed, request.duplicatePolicy
        )

        if G.number_of_nodes() == 0:
            raise HTTPException(status_code=400, detail="No valid edges found after cleaning")

        # ── 3. Network-level metrics (Fix 1: weighted summary) ───────────────
        metrics = _compute_network_metrics(
            G, is_directed,
            weighted=weighted,
            weight_interpretation=weight_interpretation,
            negative_weight_policy=negative_weight_policy,
        )

        # Flag isolated nodes in warnings
        if metrics["isolated_nodes"]:
            data_warnings["isolated_nodes"] = (
                f"{metrics['isolated_nodes']} isolated node(s) detected in the final graph"
            )

        # ── 4. Centrality measures (Fix 2 + 4: distance graph policy) ────────
        centrality = _compute_centrality(
            G, is_directed,
            weighted=weighted,
            weight_interpretation=weight_interpretation,
            negative_weight_policy=negative_weight_policy,
        )

        # ── 5. Top-5 nodes per centrality metric ──────────────────────────────
        top_nodes = {
            key: sorted(vals.items(), key=lambda x: x[1], reverse=True)[:5]
            for key, vals in centrality.items()
        }

        # ── 6. Community detection ────────────────────────────────────────────
        try:
            G_und = G.to_undirected() if is_directed else G
            communities_raw = nx.community.greedy_modularity_communities(G_und)
            communities = [list(c) for c in communities_raw]
            modularity = nx.community.modularity(
                G_und, communities_raw
            )
        except Exception as exc:
            logger.warning("Community detection failed: %s", exc)
            communities = [list(G.nodes())]
            modularity = None

        metrics["modularity"] = modularity

        # ── 7. Plotly visualisation (Fix 3: adaptive large-graph rendering) ──
        n_nodes = G.number_of_nodes()
        n_edges = G.number_of_edges()

        # Thresholds for visual simplification
        LABEL_THRESHOLD = 80    # hide labels above this node count
        SAMPLE_THRESHOLD = 500  # sample top-N nodes by degree above this

        # When the graph is very large, visualise only the top-N degree nodes
        # so the diagram remains legible. The full graph is still used for all
        # metric and centrality calculations above.
        G_vis = G
        vis_note = None
        TOP_N_VIS = 300
        if n_nodes > SAMPLE_THRESHOLD:
            top_nodes_vis = sorted(
                G.nodes(), key=lambda n: centrality["degree"].get(n, 0), reverse=True
            )[:TOP_N_VIS]
            G_vis = G.subgraph(top_nodes_vis)
            vis_note = (
                f"Visualisation shows top {TOP_N_VIS} nodes by degree "
                f"(full graph: {n_nodes} nodes, {n_edges} edges)."
            )

        # Layout selection based on graph size
        n_vis = G_vis.number_of_nodes()
        if n_vis <= 50:
            # Small: spring layout with fine tuning
            pos = nx.spring_layout(
                G_vis, k=2 / np.sqrt(max(n_vis, 1)), iterations=100, seed=42
            )
        elif n_vis <= 200:
            # Medium: kamada-kawai is slower but more structured
            try:
                pos = nx.kamada_kawai_layout(G_vis)
            except Exception:
                pos = nx.spring_layout(G_vis, k=1.5 / np.sqrt(n_vis), iterations=50, seed=42)
        else:
            # Large: fast spring layout with fewer iterations
            pos = nx.spring_layout(G_vis, k=1 / np.sqrt(n_vis), iterations=30, seed=42)

        show_labels = n_vis <= LABEL_THRESHOLD

        edge_x, edge_y = [], []
        for u, v in G_vis.edges():
            x0, y0 = pos[u]
            x1, y1 = pos[v]
            edge_x.extend([x0, x1, None])
            edge_y.extend([y0, y1, None])

        edge_trace = {
            "x": edge_x,
            "y": edge_y,
            "mode": "lines",
            "line": {"width": 0.5, "color": "#888"},
            "hoverinfo": "none",
            "type": "scatter",
        }

        community_map: dict = {}
        for i, comm in enumerate(communities):
            for node in comm:
                community_map[node] = i

        node_x, node_y, node_text, node_label, node_size, node_color = [], [], [], [], [], []
        deg_cent = centrality["degree"]
        bet_cent = centrality["betweenness"]
        clo_cent = centrality["closeness"]
        eig_cent = centrality["eigenvector"]
        pr_cent = centrality["pagerank"]

        for node in G_vis.nodes():
            x, y = pos[node]
            node_x.append(x)
            node_y.append(y)

            deg = deg_cent.get(node, 0)
            bet = bet_cent.get(node, 0)
            clo = clo_cent.get(node, 0)
            eig = eig_cent.get(node, 0)
            pr = pr_cent.get(node, 0)

            hover = (
                f"{node}"
                f"<br>Degree: {deg:.3f}"
                f"<br>Betweenness: {bet:.3f}"
                f"<br>Closeness: {clo:.3f}"
                f"<br>Eigenvector: {eig:.3f}"
                f"<br>PageRank: {pr:.3f}"
                f"<br>Community: {community_map.get(node, '–')}"
            )
            if weighted and "avg_strength" in metrics:
                strength = dict(G.degree(weight="weight")).get(node, 0)
                hover += f"<br>Strength: {strength:.3f}"
            if is_directed:
                in_deg = centrality["in_degree"].get(node, 0)
                out_deg = centrality["out_degree"].get(node, 0)
                hover += f"<br>In-degree: {in_deg:.3f}<br>Out-degree: {out_deg:.3f}"

            node_text.append(hover)
            node_label.append(str(node) if show_labels else "")
            node_size.append(max(6, 8 + deg * 35))
            node_color.append(community_map.get(node, 0))

        node_trace = {
            "x": node_x,
            "y": node_y,
            "mode": "markers+text" if show_labels else "markers",
            "hoverinfo": "text",
            "text": node_label,
            "textposition": "top center",
            "textfont": {"size": 7 if n_vis > 40 else 9},
            "hovertext": node_text,
            "marker": {
                "showscale": True,
                "colorscale": "Viridis",
                "color": node_color,
                "size": node_size,
                "colorbar": {
                    "thickness": 15,
                    "title": "Community",
                    "xanchor": "left",
                    "titleside": "right",
                },
                "line": {"width": 1 if n_vis > 100 else 2, "color": "white"},
            },
            "type": "scatter",
        }

        vis_title = "Network Visualization"
        if vis_note:
            vis_title += f" (top {TOP_N_VIS} nodes)"

        layout = {
            "title": {"text": vis_title, "font": {"size": 16}},
            "showlegend": False,
            "hovermode": "closest",
            "margin": {"b": 20, "l": 20, "r": 20, "t": 40},
            "xaxis": {"showgrid": False, "zeroline": False, "showticklabels": False},
            "yaxis": {"showgrid": False, "zeroline": False, "showticklabels": False},
            "paper_bgcolor": "rgba(0,0,0,0)",
            "plot_bgcolor": "rgba(0,0,0,0)",
        }

        plot_data = {"data": [edge_trace, node_trace], "layout": layout}

        if vis_note:
            data_warnings["visualisation_sampling"] = vis_note

        results = {
            "metrics": metrics,
            "centrality": centrality,
            "top_nodes": top_nodes,
            "communities": communities,
            "warnings": data_warnings,
            "weight_interpretation": weight_interpretation if weighted else None,
            "negative_weight_policy": negative_weight_policy if weighted else None,
        }

        return _to_native({"results": results, "plot": json.dumps(plot_data)})

    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Unexpected error in social_network_analysis")
        raise HTTPException(status_code=500, detail=str(e))
